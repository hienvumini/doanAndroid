package com.example.pandaapp.Models;

public interface ILoadmoreProduct {
    public void onLoadMore();
}
